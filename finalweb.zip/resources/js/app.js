require('./bootstrap');

require('alpinejs');

window.Swiper = require('swiper/swiper-bundle');
require('./swiper');
require('./menu');
