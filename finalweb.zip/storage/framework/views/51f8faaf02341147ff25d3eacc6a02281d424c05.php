<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Viamed Peru - <?php echo $__env->yieldContent('title'); ?></title>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>" />
        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

        <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.ico')); ?>">

    </head>
    <body>

        <div class="headertop">
            <div class="top-header bg-viamed-400">
                <div class="container flex justify-between mx-auto">
                    <div class="text-white"></div>
                    <div class="text-white my-1 mx-3"><small>Apv. Los Olivos de la Paz A-10 | San Jeronimo - Cusco - Peru</small><small> | Tef. +54 942727638</small>  </div>
                </div>
            </div>
        </div>

    <div class="sticky banner-wrapper top-0 z-50 bg-white border-b-2">
        <header x-data="{ mobileMenuOpen : false }" class="banner flex flex-wrap flex-row justify-between md:items-center md:space-x-4 bg-white py-2 px-6 relative max-w-7xl mx-auto">
            <a href="<?php echo e(route('home')); ?>" class="block">
            <span class="sr-only">Viamed Peru</span>
            <img class="w-10/12" src="<?php echo e(asset('img/logo-viamed.jpg')); ?>" alt="logo viamed"  title="logo viamed">
            </a>
            <button  @click="mobileMenuOpen = !mobileMenuOpen" class="inline-block md:hidden w-12 h-12 bg-gray-200 text-gray-600 p-1 mt-5">
            <svg fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path></svg>
            </button>
            <nav class="border z-50 sm:border-transparent absolute md:relative top-24 left-0 md:top-0  md:flex flex-col md:flex-row md:space-x-6 font-semibold w-full md:w-auto bg-white shadow-md md:rounded-none md:shadow-none md:bg-transparent p-6 pt-0 md:p-0"
            :class="{ 'flex' : mobileMenuOpen , 'hidden' : !mobileMenuOpen}"  @click.away="mobileMenuOpen = false"
            >
                <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active-menu' : ''); ?> text-viamed-700 hover:bg-viamed-500 hover:text-white px-3 py-2 rounded-md text-base font-cuprum font-semibold uppercase" >Inicio</a>
                <a href="<?php echo e(route('nosotros')); ?>" class="<?php echo e(request()->routeIs('nosotros') ? 'active-menu' : ''); ?> text-viamed-700 hover:bg-viamed-500 hover:text-white px-3 py-2 rounded-md text-base font-cuprum font-semibold uppercase">Nosotros</a>
                <a href="#" class="text-viamed-700 hover:bg-viamed-500 hover:text-white px-3 py-2 rounded-md text-base font-cuprum font-semibold uppercase">Servicios</a>
                <a href="<?php echo e(route('unidades')); ?>" class="<?php echo e(request()->routeIs('unidades') ? 'active-menu' : ''); ?> text-viamed-700 hover:bg-viamed-500 hover:text-white px-3 py-2 rounded-md text-base font-cuprum font-semibold uppercase">Nuestras Unidades</a>
                <a href="<?php echo e(route('politicas')); ?>" class="<?php echo e(request()->routeIs('politicas') ? 'active-menu' : ''); ?> text-viamed-700 hover:bg-viamed-500 hover:text-white px-3 py-2 rounded-md text-base font-cuprum font-semibold uppercase">Politicas</a>
                <a href="<?php echo e(route('contactanos')); ?>" class="<?php echo e(request()->routeIs('contactanos') ? 'active-menu' : ''); ?> text-viamed-700 hover:bg-viamed-500 hover:text-white px-3 py-2 rounded-md text-base font-cuprum font-semibold uppercase">Contactenos</a>
                <a href="<?php echo e(route('covid')); ?>" class="text-white font-extrabold bg-red-500 hover:bg-viamed-500 hover:text-white px-3 py-2 rounded-md text-base font-cuprum uppercase">COVID 19</a>
            </nav>
        </header>
    </div>

        <?php echo $__env->yieldContent('content'); ?>

        <footer class=" bg-viamed-500 text-2 text-gray-200 transition-colors duration-200 shadow-2xl">
            <div class="flex flex-col py-10">
                <div class="md:hidden mt-7 mx-auto w-11 h-px rounded-full">
                </div>
                <div class="mt-4 md:mt-0 flex flex-col md:flex-row">
                    <nav class="flex-1 flex flex-col items-center justify-center md:items-end md:border-r border-gray-100 md:pr-5">
                        <a aria-current="page" href="<?php echo e(route('nosotros')); ?>" class="hover:text-white">
                            Nosotros
                        </a>
                        <a aria-current="page" href="<?php echo e(route('unidades')); ?>" class="hover:text-white">
                            Nuestras Unidades
                        </a>
                        <a aria-current="page" href="<?php echo e(route('contactanos')); ?>" class="hover:text-white">
                            Contactenos
                        </a>
                    </nav>
                    <div class="md:hidden mt-4 mx-auto w-11 h-px rounded-full">
                    </div>
                    <div class="mt-4 md:mt-0 flex-1 flex items-center justify-center md:border-r border-gray-100">
                        <img src="<?php echo e(asset('img/logo-viamed.jpg')); ?>" alt="">

                    </div>
                    <div class="md:hidden mt-4 mx-auto w-11 h-px rounded-full ">
                    </div>
                    <div class="mt-7 md:mt-0 flex-1 flex flex-col items-center justify-center md:items-start md:pl-5">
                        <h2 class="text-2xl text-white font-rochester italic text-center">… ¡Cuidamos tus Viajes,<br> Cuidamos tu Vida!</h2>
                    </div>
                </div>
            </div>
            <div class="bg-white mt-5 text-gray-900 text-center">
                <small>2021 Viamed Peru, Inc. All Rights Reserved: Terms &amp; Conditions</small>
            </div>
        </footer>

        <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\viamed\resources\views/layouts/app2.blade.php ENDPATH**/ ?>