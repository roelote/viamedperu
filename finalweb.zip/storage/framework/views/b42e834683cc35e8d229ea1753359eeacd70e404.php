<?php $__env->startSection('title', 'Sobre Nosotros'); ?>
<?php $__env->startSection('description','Nos distinguimos por brindar un servicio distinto y fuera de lo tradicional tanto como en la organización y planificación de excursiones.'); ?>

<?php $__env->startSection('content'); ?>


<section class="flex items-center justify-center m-auto mb-5 bg-center bg-cover relative" style="background-image: url(<?php echo e(asset('img/hader-pages-viamed.jpg')); ?>)" >
    <div class="p-10  py-10  flex  flex-col  flex-wrap  justify-center  content-center z-20">
        <h1 class="text-white text-6xl font-cuprum uppercase py-20">Sobre Nosotros</h1>
    </div>
    <div class="overlay absolute bg-viamed-700 w-full h-full opacity-60"></div>
</section>

<section class="my-5 sm:py-10">
    <div class="container max-w-7xl">

        <h2 class="font-cuprum text-4xl text-center font-semibold my-3 text-viamed-500">¿QUIÉNES SOMOS?</h2>
        <span class="w-20 block h-1 bg-gray-300 mx-auto -mt-2 my-2"></span>
        <div class="my-7 mx-3">
            <p class="text-gray-700 text-justify sm:text-left">Se distingue por brindar un servicio distinto y fuera de lo tradicional tanto como en la organización y planificación de excursiones, programas de viaje y tours; tanto así contamos con principios éticos y de responsabilidad social, fomentamos el desarrollo y el bienestar de nuestros trabajadores con el compromiso continuo de mantener la seguridad en nuestras operaciones y el respeto al medio ambiente.</p>

                <p>Hoy contamos con un portafolio de profesionales abocadados a la atención personalizada del cliente, por el cual nuestros clientes buscan encontrar cómo llevar a cabo sus sueños de viajar y conocer otras culturas.
                </p>
        </div>
    </div>
</section>

<section class="py-5 sm:py-10 bg-gray-50">
    <div class="container max-w-7xl">
        <div class="grid sm:grid-cols-2 grid-cols-1 gap-8">
            <div class="mx-1 m:mx-3">
                 <h3 class="text-3xl text-center text-red-600 font-semibold py-5">VISION</h3>
                 <img src="<?php echo e(asset('img/vision.png')); ?>" class="float-left w-36 mr-5" alt="vision">
                    <p class="p-5">Ser una empresa de transporte turístico líder en el mercado turístico de la ciudad de Cusco, nacional e internacional, con productos innovadores acorde a las necesidades y exigencias de nuestros clientes, que contribuya conjuntamente con las comunidades al desarrollo socio-económico, equilibrado y sustentable para el mejoramiento de la calidad de vida de sus habitantes y el fortalecimiento de la integración comunal de la región y el país.</p>
            </div>
            <div class="mx-1 m:mx-3">
                 <h3 class="text-3xl text-center text-red-600 font-semibold py-5">MISION</h3>
                 <img src="<?php echo e(asset('img/mision.png')); ?>" class="float-right w-36 ml-5" alt="vision">
                 <p class="p-5">Brindar un servicio de calidad y confiabilidad, con el fin de lograr la plena satisfacción de nuestros clientes con nuestras rutas turísticas que le permitirán conocer y disfrutar de las maravillas de nuestro Cusco y Perú, así mismo contamos con el equipo de trabajo especializado y la tecnología propicia para brindarle un servicio personalizado que supere las expectativas de nuestros clientes. Trabajamos con gran responsabilidad respetando nuestra cultura y medio ambiente contribuyendo al desarrollo de nuestro país.</p>

            </div>
    </div>
</div>
</section>
<section class="my-5 sm:py-10">
        <div class="container max-w-7xl  px-3">

            <h2 class="font-cuprum text-3xl font-semibold my-3 text-gray-700 uppercase"> NUESTROS VALORES</h2>
            

                    <p>Ponemos en valor la transmisión de costumbres y tradiciones de nuestros antepasados, capacitando a nuestros colaboradores (Personal Administrativo, Guías, Transfers, Asistentes y Conductores) sobre la correcta forma de interactuar ante situaciones inesperadas como emergencias (Primeros auxilios), el manejo apropiado de los alimentos, el nivel de seguridad al conducir y/o traslado del participante.</p>

                <div class="grid grid-cols-2 gap-4">
                    <div class="pl-10">
                            <ul class="list-disc list-inside">
                                <li>Pasión y compromiso</li>
                                <li>Calidad y excelencia en el servicio</li>
                                <li>Confiabilidad</li>
                                <li>Responsabilidad</li>
                                <li>Puntualidad</li>
                            </ul>
                    </div>
                    <div class="pl-10">
                            <ul class="list-disc list-inside">
                                <li>Integridad y respeto</li>
                                <li>Honestidad</li>
                                <li>Innovación e inspiración</li>
                                <li>Diversión y trabajo en equipo</li>
                            </ul>
                    </div>
                </div>

                <h2 class="font-cuprum text-3xl font-semibold my-3 text-gray-700 uppercase">NUESTRA FILOSOFIA</h2>
                    
                    <p>ViaMed Perú, se preocupa por los viajes responsables, basándose en el respeto por la gente y los destinos que operamos, como también realizar un viaje ético y consciente por parte de nuestros visitantes, los cuales dada las características de este segmento muestran gran interés en la interacción con la “Vida Real” de los destinos que visitan y por ello eligen un tipo de viaje en el que no sean cómplices de destrucción y explotación de los mismos.</p>


        </div>
</section>

<section class="my-5">
    <div class="container max-w-7xl">
        <img src="<?php echo e(asset('img/nosotros-footer.jpg')); ?>" alt="foto sobre nosotros">
    </div>
</section>

 <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\viamed\resources\views/nosotros.blade.php ENDPATH**/ ?>