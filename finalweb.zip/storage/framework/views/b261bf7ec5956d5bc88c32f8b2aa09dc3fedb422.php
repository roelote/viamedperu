<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <h1>Contacto Viamed Peru</h1>

    <p><strong>Nombre:</strong><?php echo e($contacto['Nombre']); ?></p>
    <p><strong>Correo:</strong><?php echo e($contacto['Email']); ?></p>
    <p><strong>Mensaje:</strong><?php echo e($contacto['Mensaje']); ?></p>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\viamed\resources\views/mail/contactanos.blade.php ENDPATH**/ ?>